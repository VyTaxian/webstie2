# Taxian site + commission system (Vercel)

index.html          your site (commission portal now uses the server)
api/                serverless routes (public board, orders, admin)
lib/core.js         shared server code
package.json        dependency: @upstash/redis

## Deploy
1. Push this folder to GitHub (or run `vercel` in it) and import it as a Vercel project.
   Framework preset: "Other". No build command needed.
2. In the Vercel dashboard: Storage / Marketplace -> add **Upstash Redis** -> connect it to this project.
   (It adds the UPSTASH_REDIS_REST_URL / _TOKEN or KV_REST_API_URL / _TOKEN env vars for you.)
3. Project Settings -> Environment Variables, add:
   - ADMIN_PASSWORD        a NEW strong password (the old one was public in the HTML)
   - DISCORD_WEBHOOK_URL   a NEW webhook (delete the old one in Discord)
   - PUBLIC_DETAILS        optional, "false" hides request details from the public board
4. Redeploy (env vars only apply to new deployments).

## Use
- Everyone: your-site/#commission  -> live board, submit, look up an order
- You:      your-site/#admin       -> confirm / deny / complete / set price / delete
